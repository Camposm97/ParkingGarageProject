package vehicle_Tests;

import static org.junit.jupiter.api.Assertions.*;
import model.*;
import org.junit.jupiter.api.Test;


class StateT {

	@Test
	void test() {
		System.out.println(State.getAbbreviationList().toString());
		
	}

}
