/**
 * Contains the App class which brings together the whole application. 
 */
package app;