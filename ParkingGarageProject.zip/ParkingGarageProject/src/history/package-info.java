/**
 * An assistant class to the formatting and saving/loading of the DailyData log files
 * Uses primarily the util package classes
 */
package history;