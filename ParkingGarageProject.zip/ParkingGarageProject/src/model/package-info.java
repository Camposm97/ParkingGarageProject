/**
 * Holds all the data structures and methods provided for the Parking lot and User Data classes
 */
package model;