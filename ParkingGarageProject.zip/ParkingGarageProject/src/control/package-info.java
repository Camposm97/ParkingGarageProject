/**
 * Control contains more customized GUI elements that will be used on more than one occasion<br>
 */
package control;