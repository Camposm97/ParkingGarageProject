/**
 * Contains specific GUI elements to be contained into the Application<br>
 */
package view;