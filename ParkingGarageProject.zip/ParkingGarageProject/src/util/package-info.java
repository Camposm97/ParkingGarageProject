/**
 * As the name implies, this contains quick utilities utilized by other package's classes <br>
 */
package util;