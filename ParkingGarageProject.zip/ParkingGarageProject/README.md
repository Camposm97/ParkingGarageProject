# ParkingGarageProject
Parking Garage Project for CSE248 due October 7th, 2019. 
<br>Group: Michael Campos, Matt Guidi, Chris Demonte


## What could possibly go wrong?
## Nothing at all 
## But not really
## Light work light work


### and that's when it all went down hill.